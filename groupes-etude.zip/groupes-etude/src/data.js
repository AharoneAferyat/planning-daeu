import { useEffect, useState } from 'react';
import {
  addDoc, arrayRemove, arrayUnion, collection, deleteDoc, deleteField, doc, getDoc, getDocs,
  increment, limit, onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc, writeBatch,
} from 'firebase/firestore';
import { db } from './firebase';
import { DEFAULT_SETTINGS } from './config';
import { fmt, fmtDayShort, shortUA, toDate, normalizeSlots } from './utils';

// ---------- Historique ----------
export async function log(type, actor, target = '', details = {}) {
  try {
    const clean = JSON.parse(JSON.stringify(details ?? {}));
    await addDoc(collection(db, 'logs'), {
      type, actor: actor || '?', target: target || '', details: clean, ua: shortUA(), at: serverTimestamp(),
    });
  } catch (e) { console.warn('log', e); }
}

// ---------- Hooks temps réel ----------
function useCol(name, map, sort) {
  const [rows, setRows] = useState(null);
  useEffect(() => onSnapshot(collection(db, name), (snap) => {
    let r = snap.docs.map((d) => map(d));
    if (sort) r = r.sort(sort);
    setRows(r);
  }, (e) => { console.error(name, e); setRows([]); }), [name]);
  return rows;
}
const byCreatedDesc = (a, b) => (toDate(b.createdAt)?.getTime() || Date.now()) - (toDate(a.createdAt)?.getTime() || Date.now());

export function useSettings() {
  const [settings, setSettings] = useState(null);
  useEffect(() => onSnapshot(doc(db, 'config', 'settings'),
    (s) => setSettings({ ...DEFAULT_SETTINGS, ...(s.exists() ? s.data() : {}) }),
    () => setSettings({ ...DEFAULT_SETTINGS })), []);
  return settings;
}
export const useParticipants = () => useCol('participants', (d) => ({ id: d.id, ...d.data() }),
  (a, b) => (a.prenom || '').localeCompare(b.prenom || '', 'fr') || (a.nom || '').localeCompare(b.nom || '', 'fr'));
export const useInvites = () => useCol('invites', (d) => ({ code: d.id, ...d.data() }), byCreatedDesc);
export const usePolls = () => useCol('polls', (d) => ({ id: d.id, ...d.data() }), byCreatedDesc);
export const useSessions = () => useCol('sessions', (d) => ({ id: d.id, ...d.data() }),
  (a, b) => (a.date + String(a.s).padStart(4, '0')).localeCompare(b.date + String(b.s).padStart(4, '0')));

export function useLogs(max = 500) {
  const [logs, setLogs] = useState(null);
  useEffect(() => onSnapshot(query(collection(db, 'logs'), orderBy('at', 'desc'), limit(max)),
    (snap) => setLogs(snap.docs.map((d) => ({ id: d.id, ...d.data() })))), [max]);
  return logs;
}

// ---------- Codes d'invitation ----------
export function inviteStatus(inv) {
  if (!inv) return { key: 'unknown', label: 'Inconnu' };
  if (!inv.active) return { key: 'off', label: 'Désactivé' };
  const exp = toDate(inv.expiresAt);
  if (exp && exp < new Date()) return { key: 'expired', label: 'Expiré' };
  if (inv.maxUses > 0 && (inv.uses || 0) >= inv.maxUses) return { key: 'full', label: 'Épuisé' };
  return { key: 'ok', label: 'Actif' };
}

export async function checkInvite(code, { alreadyUsed = false } = {}) {
  const c = (code || '').trim().toUpperCase();
  if (!c) return { ok: false, reason: 'Entre un code' };
  const snap = await getDoc(doc(db, 'invites', c));
  if (!snap.exists()) return { ok: false, reason: 'Ce code n’existe pas' };
  const inv = { code: c, ...snap.data() };
  const st = inviteStatus(inv);
  if (st.key === 'off') return { ok: false, reason: 'Ce code a été désactivé' };
  if (st.key === 'expired') return { ok: false, reason: 'Ce code a expiré' };
  if (st.key === 'full' && !alreadyUsed) return { ok: false, reason: 'Ce code a atteint son nombre max d’utilisations' };
  return { ok: true, inv };
}

export async function consumeInvite(code) {
  await updateDoc(doc(db, 'invites', code), { uses: increment(1), lastUsedAt: serverTimestamp() });
  await log('invite_use', 'Visiteur', code);
}

export async function saveInvite(code, data, isNew) {
  const printable = { ...data, expiresAt: data.expiresAt ? toDate(data.expiresAt).toISOString() : null };
  if (isNew) {
    const exists = await getDoc(doc(db, 'invites', code));
    if (exists.exists()) throw new Error('Ce code existe déjà');
    await setDoc(doc(db, 'invites', code), { ...data, uses: 0, createdAt: serverTimestamp() });
    await log('invite_create', 'Admin', code, printable);
  } else {
    await updateDoc(doc(db, 'invites', code), { ...data, updatedAt: serverTimestamp() });
    await log('invite_update', 'Admin', code, printable);
  }
}
export async function setInviteActive(code, active) {
  await updateDoc(doc(db, 'invites', code), { active, updatedAt: serverTimestamp() });
  await log('invite_update', 'Admin', code, { active });
}
export async function resetInviteUses(code) {
  await updateDoc(doc(db, 'invites', code), { uses: 0, updatedAt: serverTimestamp() });
  await log('invite_update', 'Admin', code, { uses: 0 });
}
export async function deleteInvite(code) {
  await deleteDoc(doc(db, 'invites', code));
  await log('invite_delete', 'Admin', code);
}

// ---------- Participants ----------
export async function createParticipant(data) {
  const ref = await addDoc(collection(db, 'participants'), {
    ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp(), lastSeenAt: serverTimestamp(), updates: 0,
  });
  return ref.id;
}
export async function updateParticipant(id, data) {
  await updateDoc(doc(db, 'participants', id), { ...data, updatedAt: serverTimestamp(), updates: increment(1) });
}
export async function touchParticipant(id) {
  try { await updateDoc(doc(db, 'participants', id), { lastSeenAt: serverTimestamp() }); } catch { /* */ }
}

// Retire une personne des sondages / séances
async function detachFromActivities(id, replaceBy = null) {
  const polls = await getDocs(collection(db, 'polls'));
  for (const p of polls.docs) {
    const v = p.data().votes || {};
    if (!v[id]) continue;
    const upd = { [`votes.${id}`]: deleteField() };
    if (replaceBy && !v[replaceBy]) upd[`votes.${replaceBy}`] = v[id];
    await updateDoc(p.ref, upd);
  }
  const sessions = await getDocs(collection(db, 'sessions'));
  for (const s of sessions.docs) {
    const att = s.data().attendees || [];
    if (!att.includes(id)) continue;
    let next = att.filter((x) => x !== id);
    if (replaceBy && !next.includes(replaceBy)) next = [...next, replaceBy];
    await updateDoc(s.ref, { attendees: next });
  }
}

export async function deleteParticipant(p, actor) {
  await detachFromActivities(p.id);
  await deleteDoc(doc(db, 'participants', p.id));
  await log('participant_delete', actor, `${p.prenom} ${p.nom || ''}`.trim(), { id: p.id });
}

// Fusionne "source" dans "target" (garde target, réunit les créneaux, transfère votes et séances)
export async function mergeParticipants(target, source) {
  const slots = normalizeSlots([...(target.slots || []), ...(source.slots || [])]);
  await detachFromActivities(source.id, target.id);
  await updateDoc(doc(db, 'participants', target.id), {
    slots, updatedAt: serverTimestamp(), updates: increment(1),
    note: [target.note, source.note].filter(Boolean).join(' / ').slice(0, 200),
  });
  await deleteDoc(doc(db, 'participants', source.id));
  await log('participant_merge', 'Admin', `${target.prenom} ${target.nom || ''}`.trim(),
    { fusionne: `${source.prenom} ${source.nom || ''}`.trim(), gardé: target.id, supprimé: source.id });
}

// ---------- Sondages ----------
export async function createPoll(data, me) {
  const ref = await addDoc(collection(db, 'polls'), {
    ...data, votes: {}, status: 'open', createdBy: me.id, createdByName: `${me.prenom} ${me.nom || ''}`.trim(),
    createdAt: serverTimestamp(),
  });
  await log('poll_create', `${me.prenom} ${me.nom || ''}`.trim(), data.title, { options: data.options.length });
  return ref.id;
}
export async function updatePoll(id, data, actor, title) {
  await updateDoc(doc(db, 'polls', id), { ...data, updatedAt: serverTimestamp() });
  await log('poll_update', actor, title, {});
}
export async function votePoll(poll, me, choices) {
  await updateDoc(doc(db, 'polls', poll.id), { [`votes.${me.id}`]: choices });
  const resume = poll.options.map((o) => `${fmtDayShort(o.date)} ${fmt(o.s)} : ${choices[o.id] === 'yes' ? 'oui' : choices[o.id] === 'maybe' ? 'si besoin' : choices[o.id] === 'no' ? 'non' : '—'}`);
  await log('poll_vote', `${me.prenom} ${me.nom || ''}`.trim(), poll.title, { votes: resume });
}
export async function closePoll(poll, option, extra, actor) {
  const votes = poll.votes || {};
  const attendees = Object.keys(votes).filter((pid) => votes[pid]?.[option.id] === 'yes' || votes[pid]?.[option.id] === 'maybe');
  const sRef = await addDoc(collection(db, 'sessions'), {
    title: poll.title, date: option.date, s: option.s, e: option.e,
    format: extra.format || poll.format || 'hybride', place: extra.place ?? poll.place ?? '', note: poll.description || '',
    attendees, pollId: poll.id, createdBy: poll.createdBy, createdByName: poll.createdByName, createdAt: serverTimestamp(),
  });
  await updateDoc(doc(db, 'polls', poll.id), { status: 'closed', finalOptionId: option.id, sessionId: sRef.id, closedAt: serverTimestamp() });
  await log('poll_close', actor, poll.title, { date: `${fmtDayShort(option.date)} ${fmt(option.s)}–${fmt(option.e)}`, inscrits: attendees.length });
  return sRef.id;
}
export async function reopenPoll(poll, actor) {
  if (poll.sessionId) { try { await deleteDoc(doc(db, 'sessions', poll.sessionId)); } catch { /* */ } }
  await updateDoc(doc(db, 'polls', poll.id), { status: 'open', finalOptionId: deleteField(), sessionId: deleteField() });
  await log('poll_reopen', actor, poll.title);
}
export async function deletePoll(poll, actor) {
  await deleteDoc(doc(db, 'polls', poll.id));
  await log('poll_delete', actor, poll.title);
}

// ---------- Séances ----------
export async function createSession(data, me) {
  const ref = await addDoc(collection(db, 'sessions'), {
    ...data, attendees: data.attendees || [me.id], createdBy: me.id,
    createdByName: `${me.prenom} ${me.nom || ''}`.trim(), createdAt: serverTimestamp(),
  });
  await log('session_create', `${me.prenom} ${me.nom || ''}`.trim(), data.title, { date: `${fmtDayShort(data.date)} ${fmt(data.s)}–${fmt(data.e)}` });
  return ref.id;
}
export async function updateSession(id, data, actor, title) {
  await updateDoc(doc(db, 'sessions', id), { ...data, updatedAt: serverTimestamp() });
  await log('session_update', actor, title, data.date ? { date: `${fmtDayShort(data.date)} ${fmt(data.s)}–${fmt(data.e)}` } : {});
}
export async function joinSession(s, me, join) {
  await updateDoc(doc(db, 'sessions', s.id), { attendees: join ? arrayUnion(me.id) : arrayRemove(me.id) });
  await log(join ? 'session_join' : 'session_leave', `${me.prenom} ${me.nom || ''}`.trim(), s.title, { date: `${fmtDayShort(s.date)} ${fmt(s.s)}` });
}
export async function deleteSession(s, actor) {
  await deleteDoc(doc(db, 'sessions', s.id));
  if (s.pollId) { try { await updateDoc(doc(db, 'polls', s.pollId), { status: 'open', finalOptionId: deleteField(), sessionId: deleteField() }); } catch { /* */ } }
  await log('session_delete', actor, s.title, { date: `${fmtDayShort(s.date)} ${fmt(s.s)}` });
}

// ---------- Réglages / maintenance ----------
export async function saveSettings(data, details) {
  await setDoc(doc(db, 'config', 'settings'), data, { merge: true });
  await log('settings_update', 'Admin', '', details || {});
}

export async function wipeCollection(name) {
  const snap = await getDocs(collection(db, name));
  let batch = writeBatch(db), n = 0;
  for (const d of snap.docs) {
    batch.delete(d.ref);
    if (++n % 400 === 0) { await batch.commit(); batch = writeBatch(db); }
  }
  await batch.commit();
  return snap.size;
}

export async function fetchAll(name) {
  const snap = await getDocs(collection(db, name));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}
